const ROLES = {
  admin: 2200,
  user: 1500,
};

module.exports = ROLES;
