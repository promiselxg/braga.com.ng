const asyncHandler = require('express-async-handler');
const Category = require('../models/categoryModel');
const Room = require('../models/roomModel');
const { removeUploadedImage } = require('../utils/cloudinary');
//  get All Category
const getAllCategory = asyncHandler(async (req, res) => {
  res.status(200).json(res.queryResults);
});
//  Create new Category
const newCategory = asyncHandler(async (req, res) => {
  const photos = req.body.photos;
  const photoId = photos.map((url) => url.public_id.split('/')[1]);
  const { name, type, cheapestPrice } = req.body;
  if (!name || !type || !cheapestPrice) {
    res.status(403);
    throw new Error('Please fill out the form.');
  }
  try {
    //    check if category exist
    const nameExist = await Category.findOne({ type: type });
    if (nameExist) {
      removeUploadedImage(photoId, 'category');
      res.status(400);
      throw new Error('Category already exist.');
    }
    //    save to db
    const response = await Category.create({
      name,
      type,
      cheapestPrice,
      image_url: photos.map((url) => url.secure_url),
      imageId: photos.map((url) => url.public_id.split('/')[1]),
    });
    if (response) {
      return res.status(200).json({
        status: 'success',
        message: 'New category created successfully.',
        data: response,
      });
    }
  } catch (error) {
    removeUploadedImage(photoId, 'category');
    res.status(400);
    throw new Error(error);
  }
});
//  Update Category
const updateCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const photos = req.body.photos;
  const photoId = photos.map((url) => url.public_id.split('/')[1]);
  if (!id) {
    removeUploadedImage(photoId, 'category');
    res.status(400);
    throw new Error('Invalid request.');
  }
  try {
    //    check if Id exits
    const category = await Category.findById(id);
    if (!category) {
      removeUploadedImage(photoId, 'category');
      res.status(404);
      throw new Error('This ID does not exist.');
    }
    removeUploadedImage(category.imageId, 'category');

    await Category.findByIdAndUpdate(
      id,
      {
        $set: {
          name: req.body.name,
          type: req.body.type,
          cheapestPrice: req.body.cheapestPrice,
          image_url: photos.map((url) => url.secure_url),
          imageId: photos.map((url) => url.public_id.split('/')[1]),
        },
      },
      { new: true }
    );

    return res.status(200).json({
      status: 'success',
      message: 'Category successfully updated.',
    });
  } catch (error) {
    removeUploadedImage(photoId, 'category');
    res.status(400);
    throw new Error(error);
  }
});
//  Delete Category
const deleteCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  const photoId = photos.map((url) => url.public_id.split('/')[1]);
  if (!id) {
    res.status(400);
    throw new Error('Invalid Request.');
  }
  try {
    // check if ID exist
    const category = await Category.findById(id);
    if (!category) {
      removeUploadedImage(photoId, 'category');
      res.status(401);
      throw new Error('Request ID does not exist.');
    }
    //  delete category
    removeUploadedImage(category.imageId, 'category');
    if (await Category.findByIdAndDelete(id)) {
      res
        .status(200)
        .json({ status: 'success', message: 'Category successfully removed' });
    }
  } catch (error) {
    removeUploadedImage(photoId, 'category');
    res.status(400);
    throw new Error(error);
  }
});

//  Get Single Category
const singleCategory = asyncHandler(async (req, res) => {
  const { id } = req.params;
  if (!id) {
    return res.status(400).json({
      status: 'false',
      message: 'Invalid Category ID.',
    });
  }
  try {
    if (!(await Category.findById(id))) {
      return res.status(400).json({
        status: 'false',
        message: 'The Category ID does not exist.',
      });
    }
    const response = await Category.findOne({ _id: id });
    const rooms = await Promise.all(
      response.rooms.map((room) => {
        return Room.findById(room).select(
          '_id imgThumbnail price title unavailableDates'
        );
      })
    );
    return res.status(200).json({
      status: 'success',
      data: response,
      rooms,
    });
  } catch (error) {
    res.status(400);
    throw new Error(error);
  }
});

module.exports = {
  getAllCategory,
  newCategory,
  updateCategory,
  deleteCategory,
  singleCategory,
};
